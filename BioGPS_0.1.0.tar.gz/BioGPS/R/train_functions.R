#' @title R packages batch installation.
#' @description The function is batch installation dependence R packages.
#' @author Hongshan Wu
#' @param Gdata A data frame containing genomic data, where rows represent samples and columns represent SNPs.
#' @param Pdata A data frame containing phenomic data, where rows correspond to samples and columns represent traits.
#' @param Target A vector specifying the target variable to be predicted.
#' @param model A string indicating the model type to be used (e.g., "Lasso_1", "RF_500","SVM","XGBoost_100","LightGBM_100").
#' @param k An integer specifying the number of folds for cross-validation.
#' @param seed An integer to set the random seed for reproducibility.
#' @param nrounds An integer indicating the number of boosting rounds (if applicable).
#'
#' @return A data frame containing model performance metrics (e.g., accuracy, AUC).
#' @export
BioGPS_R.train <- function(Gdata = Gdata, Pdata = Pdata, Target = Target, model = model, k = k, seed = seed, nrounds = nrounds){
  options(warn = 0)
  if(!require(dplyr)){
    install.packages("dplyr")
    library(dplyr)
  }
  if(!require(caret)){
    install.packages("caret")
    library(caret)
  }
  if(!require(neuralnet)){
    install.packages("neuralnet")
    library(neuralnet)
  }
  if(!require(DEoptim)){
    install.packages("DEoptim")
    library(DEoptim)
  }
  objective_function <- function(weights, G_predictions, P_predictions, true_labels) {
    weighted_predictions <- weights[1] * G_predictions + weights[2] * P_predictions
    rmse <- sqrt(mean((weighted_predictions - true_labels)^2))
    return(rmse)
  }
  Gdata <- as.matrix(Gdata)
  Pdata <- as.matrix(Pdata)
  Target <- as.matrix(Target)
  if (ncol(Pdata) < 2) {
    print("The number of features contained in Pdata is less than 2, which is insufficient for use.")
  }
  if (ncol(Gdata) < 2) {
    print("The number of features contained in Gdata is less than 2, which is insufficient for use.")
  }
  if (ncol(Target) > 1) {
    print("The number of target traits is greater than 1, which is insufficient for use.")
  }
  if(any(is.na(Gdata))){
    message("There are empty values in the Gdata.")
  }
  if(any(is.na(Pdata))){
    message("There are empty values in the Pdata.")
  }
  if(any(is.na(Target))){
    message("There are empty values in the Target.")
  }
  if (nrow(Gdata) != nrow(Pdata) || nrow(Pdata) != nrow(Target)) {
    print("The number of samples in the input data is different.")
  }
  feature_G <- as.data.frame(Gdata)
  feature_P <- as.data.frame(Pdata)
  response <- as.numeric(Target)
  folds <- createFolds(response, k = k, list = TRUE, returnTrain = FALSE)
  all_val_preds <- c()
  all_actuals <- c()
  for(i in 1:k) {
    set.seed(seed)
    train_index <- unlist(folds[-i])
    test_index <- folds[[i]]
    feature_G_train <- feature_G[train_index, ]
    feature_P_train <- feature_P[train_index, ]
    response_train <- response[train_index]
    feature_G_test <- feature_G[test_index, ]
    feature_P_test <- feature_P[test_index, ]
    response_test <- response[test_index]
    if(grepl("RF", model)){
      if(!require(ranger)){
        install.packages("ranger")
        library(ranger)
      }
      rf_G <- strsplit(model, "_")[[1]]
      ntree_G <- as.numeric(rf_G[2])
      G_RF_model <- ranger(x = feature_G_train, y = response_train, num.trees = ntree_G)
      pred_G <- predict(G_RF_model, feature_G_test)$predictions
      pred_G_train <- predict(G_RF_model, feature_G_train)$predictions
    }else if(grepl("Lasso", model)){
      if(!require(glmnet)){
        install.packages("glmnet")
        library(glmnet)
      }
      la_G <- strsplit(model, "_")[[1]]
      alpha_G <- as.numeric(la_G[2])
      feature_G_train <- as.matrix(feature_G_train)
      feature_G_test <- as.matrix(feature_G_test)
      cv_fit_gene <- cv.glmnet(feature_G_train, response_train, alpha = alpha_G)
      best_lambda_G <- cv_fit_gene$lambda.min
      G_Lasso_model <- glmnet(feature_G_train, response_train, alpha = alpha_G, lambda = best_lambda_G)
      pred_G <- predict(G_Lasso_model, s = best_lambda_G, newx = feature_G_test)
      pred_G_train <- predict(G_Lasso_model, s = best_lambda_G, newx = feature_G_train)
    }else if(grepl("LightGBM", model)){
      if(!require(lightgbm)){
        install.packages("lightgbm")
        library(lightgbm)
      }
      li_G <- strsplit(model, "_")[[1]]
      nrounds_G <- as.numeric(li_G[2])
      colnames(feature_G_train) <- make.names(colnames(feature_G_train))
      colnames(feature_G_test) <- make.names(colnames(feature_G_test))
      train_data_G <- lgb.Dataset(data = as.matrix(feature_G_train), label = response_train)
      test_data_G <- lgb.Dataset(data = as.matrix(feature_G_test), label = response_test)
      params <- list(
        objective = "regression",  # 回归任务
        metric = "rmse",           # 评估指标为均方根误差
        learning_rate = 0.1,
        num_leaves = 31,
        min_data_in_leaf = 20
      )
      G_Lightgbm_model <- lgb.train(params = params,
                                    data = train_data_G,
                                    nrounds = nrounds_G,
                                    valids = list(test = test_data_G),
                                    early_stopping_rounds = 10,
                                    verbose = 0)
      pred_G <- predict(G_Lightgbm_model, as.matrix(feature_G_test), num_iteration = G_Lightgbm_model$best_iteration)
      pred_G_train <- predict(G_Lightgbm_model, as.matrix(feature_G_train), num_iteration = G_Lightgbm_model$best_iteration)
    }else if(grepl("SVM", model)){
      if(!require(e1071)){
        install.packages("e1071")
        library(e1071)
      }
      G_SVM_model <- svm(feature_G_train, response_train, kernel = "linear", cost = 10, scale = TRUE, type = "eps-regression")
      pred_G <- predict(G_SVM_model,feature_G_test)
      pred_G_train <- predict(G_SVM_model,feature_G_train)
    }else if(grepl("XGBoost", model)){
      if(!require(xgboost)){
        install.packages("xgboost")
        library(xgboost)
      }
      xg_G <- strsplit(model, "_")[[1]]
      nrounds_G <- as.numeric(xg_G[2])
      params <- list(
        objective = "reg:squarederror",  # 回归任务的目标函数
        eval_metric = "rmse"             # 评估指标为均方根误差
      )
      G_XGBoost_model <- xgboost(data = as.matrix(feature_G_train),
                                 label = response_train,
                                 nrounds = nrounds_G,
                                 params = params,
                                 verbose = 0)
      pred_G <- predict(G_XGBoost_model, as.matrix(feature_G_test))
      pred_G_train <- predict(G_XGBoost_model, as.matrix(feature_G_train))
    }else{
      message("The input model is incorrect.")
    }
    if(grepl("RF", model)){
      if(!require(ranger)){
        install.packages("ranger")
        library(ranger)
      }
      rf_P <- strsplit(model, "_")[[1]]
      ntree_P <- as.numeric(rf_P[2])
      P_RF_model <- ranger(x = feature_P_train, y = response_train, num.trees = ntree_P)
      pred_P <- predict(P_RF_model, feature_P_test)$predictions
      pred_P_train <- predict(P_RF_model, feature_P_train)$predictions
    }else if(grepl("Lasso", model)){
      if(!require(glmnet)){
        install.packages("glmnet")
        library(glmnet)
      }
      la_P <- strsplit(model, "_")[[1]]
      alpha_P <- as.numeric(la_P[2])
      feature_P_train <- as.matrix(feature_P_train)
      feature_P_test <- as.matrix(feature_P_test)
      cv_fit_phen <- cv.glmnet(feature_P_train, response_train, alpha = alpha_P)
      best_lambda_P <- cv_fit_phen$lambda.min
      P_Lasso_model <- glmnet(feature_P_train, response_train, alpha = alpha_P, lambda = best_lambda_P)
      pred_P <- predict(P_Lasso_model, s = best_lambda_P, newx = feature_P_test)
      pred_P_train <- predict(P_Lasso_model, s = best_lambda_P, newx = feature_P_train)
    }else if(grepl("LightGBM", model)){
      if(!require(lightgbm)){
        install.packages("lightgbm")
        library(lightgbm)
      }
      li_P <- strsplit(model, "_")[[1]]
      nrounds_P <- as.numeric(li_P[2])
      colnames(feature_P_train) <- make.names(colnames(feature_P_train))
      colnames(feature_P_test) <- make.names(colnames(feature_P_test))
      train_data_P <- lgb.Dataset(data = as.matrix(feature_P_train), label = response_train)
      test_data_P <- lgb.Dataset(data = as.matrix(feature_P_test), label = response_test)
      params <- list(
        objective = "regression",  # 回归任务
        metric = "rmse",           # 评估指标为均方根误差
        learning_rate = 0.1,
        num_leaves = 31,
        min_data_in_leaf = 20
      )
      P_Lightgbm_model <- lgb.train(params = params,
                                    data = train_data_P,
                                    nrounds = nrounds_P,
                                    valids = list(test = test_data_P),
                                    early_stopping_rounds = 10,
                                    verbose = 0)
      pred_P <- predict(P_Lightgbm_model, as.matrix(feature_P_test), num_iteration = P_Lightgbm_model$best_iteration)
      pred_P_train <- predict(P_Lightgbm_model, as.matrix(feature_P_train), num_iteration = P_Lightgbm_model$best_iteration)
    }else if(grepl("SVM", model)){
      if(!require(e1071)){
        install.packages("e1071")
        library(e1071)
      }
      P_SVM_model <- svm(feature_P_train, response_train, kernel = "linear", cost = 10, scale = TRUE, type = "eps-regression")
      pred_P <- predict(P_SVM_model,feature_P_test)
      pred_P_train <- predict(P_SVM_model,feature_P_train)
    }else if(grepl("XGBoost", model)){
      if(!require(xgboost)){
        install.packages("xgboost")
        library(xgboost)
      }
      xg_P <- strsplit(model, "_")[[1]]
      nrounds_P <- as.numeric(xg_P[2])
      params <- list(
        objective = "reg:squarederror",  # 回归任务的目标函数
        eval_metric = "rmse"             # 评估指标为均方根误差
      )
      P_XGBoost_model <- xgboost(data = as.matrix(feature_P_train),
                                 label = response_train,
                                 nrounds = nrounds_P,
                                 params = params,
                                 verbose = 0)
      pred_P <- predict(P_XGBoost_model, as.matrix(feature_P_test))
      pred_P_train <- predict(P_XGBoost_model, as.matrix(feature_P_train))
    }else{
      message("The input model is incorrect.")
    }
    pred_G <- as.numeric(pred_G)
    pred_P <- as.numeric(pred_P)
    weight_GP <- DEoptim(objective_function, lower = c(0, 0), upper = c(1, 1),
                         G_predictions = pred_G_train, P_predictions = pred_P_train,
                         true_labels = response_train,
                         control = DEoptim.control(itermax = nrounds))
    G_weight <- weight_GP$optim$bestmem[1]
    P_weight <- weight_GP$optim$bestmem[2]
    val_preds <- pred_G * G_weight + pred_P * P_weight
    all_val_preds <- c(all_val_preds, val_preds)
    all_actuals <- c(all_actuals, response_test)
  }
  out <- data.frame(all_actuals, all_val_preds)
  return(out)
}
#' @export
BioGPS_D.train <- function(Gdata = Gdata, Pdata = Pdata, Target = Target, model = model, k = k, seed = seed){
  options(warn = 0)
  if(!require(caret)){
    install.packages("caret")
    library(caret)
  }
  Gdata <- as.matrix(Gdata)
  Pdata <- as.matrix(Pdata)
  Target <- as.matrix(Target)
  if (ncol(Gdata) < 2) {
    print("The number of features contained in Gdata is less than 2, which is insufficient for use.")
  }
  if (ncol(Target) > 1) {
    print("The number of target traits is greater than 1, which is insufficient for use.")
  }
  if(any(is.na(Gdata))){
    message("There are empty values in the Gdata.")
  }
  if(any(is.na(Pdata))){
    message("There are empty values in the Pdata.")
  }
  if(any(is.na(Target))){
    message("There are empty values in the Target.")
  }
  if (nrow(Gdata) != nrow(Pdata) || nrow(Pdata) != nrow(Target)) {
    print("The number of samples in the input data is different.")
  }
  feature_G <- as.data.frame(Gdata)
  old_feature_P <- as.data.frame(Pdata)
  feature_P <- scale(old_feature_P)
  feature_total <- cbind(feature_P,feature_G)
  new_col_names <- as.character(1:ncol(feature_total))
  colnames(feature_total) <- new_col_names
  response <- as.numeric(Target)
  folds <- createFolds(response, k = k, list = TRUE, returnTrain = FALSE)
  all_val_preds <- c()
  all_actuals <- c()
  for(i in 1:k) {
    set.seed(seed)
    train_index <- unlist(folds[-i])
    test_index <- folds[[i]]
    feature_total_train <- feature_total[train_index, ]
    response_train <- response[train_index]
    feature_total_test <- feature_total[test_index, ]
    response_test <- response[test_index]
    if(grepl("RF", model)){
      if(!require(ranger)){
        install.packages("ranger")
        library(ranger)
      }
      ##RF_500
      rf_t <- strsplit(model, "_")[[1]]
      ntree_t <- as.numeric(rf_t[2])
      RF_model <- ranger(x = feature_total_train, y = response_train, num.trees = ntree_t)
      pred_t <- predict(RF_model, feature_total_test)$predictions
    }else if(grepl("Lasso", model)){
      if(!require(glmnet)){
        install.packages("glmnet")
        library(glmnet)
      }
      ##Lasso_1
      la_t <- strsplit(model, "_")[[1]]
      alpha_t <- as.numeric(la_t[2])
      feature_total_train <- as.matrix(feature_total_train)
      feature_total_test <- as.matrix(feature_total_test)
      response_train <- as.numeric(response_train)
      cv_fit_t <- cv.glmnet(feature_total_train, response_train, alpha = alpha_t)
      best_lambda_t <- cv_fit_t$lambda.min
      Lasso_model <- glmnet(feature_total_train, response_train, alpha = alpha_t, lambda = best_lambda_t)
      pred_t <- predict(Lasso_model, s = best_lambda_t, newx = feature_total_test)
    }else if(grepl("LightGBM", model)){
      if(!require(lightgbm)){
        install.packages("lightgbm")
        library(lightgbm)
      }
      ##LightGBM_200
      li_t <- strsplit(model, "_")[[1]]
      nrounds_t <- as.numeric(li_t[2])
      colnames(feature_total_train) <- make.names(colnames(feature_total_train))
      colnames(feature_total_test) <- make.names(colnames(feature_total_test))
      train_data_t <- lgb.Dataset(data = as.matrix(feature_total_train), label = response_train)
      test_data_t <- lgb.Dataset(data = as.matrix(feature_total_test), label = response_test)
      params <- list(
        objective = "regression",  # 回归任务
        metric = "rmse",           # 评估指标为均方根误差
        learning_rate = 0.1,
        num_leaves = 31,
        min_data_in_leaf = 20
      )
      Lightgbm_model <- lgb.train(params = params,
                                  data = train_data_t,
                                  nrounds = nrounds_t,
                                  valids = list(test = test_data_t),
                                  early_stopping_rounds = 10,
                                  verbose = 0)
      pred_t <- predict(Lightgbm_model, as.matrix(feature_total_test), num_iteration = Lightgbm_model$best_iteration)
    }else if(grepl("SVM", model)){
      if(!require(e1071)){
        install.packages("e1071")
        library(e1071)
      }
      SVM_model <- svm(feature_total_train, response_train, kernel = "linear", cost = 10, scale = TRUE, type = "eps-regression")
      pred_t <- predict(SVM_model,feature_total_test)
    }else if(grepl("XGBoost", model)){
      if(!require(xgboost)){
        install.packages("xgboost")
        library(xgboost)
      }
      ##XGBoost_200
      xg_t <- strsplit(model, "_")[[1]]
      nrounds_t <- as.numeric(xg_t[2])
      params <- list(
        objective = "reg:squarederror",  # 回归任务的目标函数
        eval_metric = "rmse"             # 评估指标为均方根误差
      )
      XGBoost_model <- xgboost(data = as.matrix(feature_total_train),
                               label = response_train,
                               nrounds = nrounds_t,
                               params = params,
                               verbose = 0)
      pred_t <- predict(XGBoost_model, as.matrix(feature_total_test))
    }else{
      message("The input model is incorrect.")
    }
    pred_t <- as.numeric(pred_t)
    all_val_preds <- c(all_val_preds, pred_t)
    all_actuals <- c(all_actuals, response_test)
  }
  results <- data.frame(all_actuals, all_val_preds)
  return(results)
}
#' @export
BioGPS_F.train <- function(Gdata = Gdata, Pdata = Pdata, Target = Target, model = model, k = k, seed = seed){
  options(warn = 0)
  if(!require(dplyr)){
    install.packages("dplyr")
    library(dplyr)
  }
  if(!require(caret)){
    install.packages("caret")
    library(caret)
  }
  if(!require(neuralnet)){
    install.packages("neuralnet")
    library(neuralnet)
  }
  if(!require(DEoptim)){
    install.packages("DEoptim")
    library(DEoptim)
  }
  objective_function <- function(weights, G_predictions, P_predictions, true_labels) {
    weighted_predictions <- weights[1] * G_predictions + weights[2] * P_predictions
    rmse <- sqrt(mean((weighted_predictions - true_labels)^2))
    return(rmse)
  }
  Gdata <- as.matrix(Gdata)
  Pdata <- as.matrix(Pdata)
  Target <- as.matrix(Target)
  if (ncol(Pdata) < 2) {
    print("The number of features contained in Pdata is less than 2, which is insufficient for use.")
  }
  if (ncol(Gdata) < 2) {
    print("The number of features contained in Gdata is less than 2, which is insufficient for use.")
  }
  if (ncol(Target) > 1) {
    print("The number of target traits is greater than 1, which is insufficient for use.")
  }
  if(any(is.na(Gdata))){
    message("There are empty values in the Gdata.")
  }
  if(any(is.na(Pdata))){
    message("There are empty values in the Pdata.")
  }
  if(any(is.na(Target))){
    message("There are empty values in the Target.")
  }
  if (nrow(Gdata) != nrow(Pdata) || nrow(Pdata) != nrow(Target)) {
    print("The number of samples in the input data is different.")
  }
  feature_G <- as.data.frame(Gdata)
  feature_P <- as.data.frame(Pdata)
  response <- as.numeric(Target)
  folds <- createFolds(response, k = k, list = TRUE, returnTrain = FALSE)
  all_val_preds <- c()
  all_actuals <- c()
  for(i in 1:k) {
    set.seed(seed)
    train_index <- unlist(folds[-i])
    test_index <- folds[[i]]
    feature_G_train <- feature_G[train_index, ]
    feature_P_train <- feature_P[train_index, ]
    response_train <- response[train_index]
    feature_G_test <- feature_G[test_index, ]
    feature_P_test <- feature_P[test_index, ]
    response_test <- response[test_index]
    if(grepl("RF", model)){
      if(!require(ranger)){
        install.packages("ranger")
        library(ranger)
      }
      rf <- strsplit(model, "_")[[1]]
      ntree <- as.numeric(rf[2])
      G_RF_model <- ranger(x = feature_G_train, y = response_train, num.trees = ntree, probability = TRUE)
      predictions_G <- predict(G_RF_model, data = feature_G_train, type = "response")$predictions
      P_RF_model <- ranger(x = feature_P_train, y = response_train, num.trees = ntree, probability = TRUE)
      predictions_P <- predict(P_RF_model, data = feature_P_train, type = "response")$predictions
      train_features <- cbind(predictions_G,predictions_P)
      train_features <- as.data.frame(train_features)
      RF_model <- ranger(x = train_features, y = response_train)
      pred_G <- predict(G_RF_model, data = feature_G_test, type = "response")$predictions
      pred_P <- predict(P_RF_model, data = feature_P_test, type = "response")$predictions
      test_features <- cbind(pred_G,pred_P)
      test_features <- as.data.frame(test_features)
      final_pred <- predict(RF_model,test_features)$predictions
    }else if(grepl("Lasso", model)){
      if(!require(glmnet)){
        install.packages("glmnet")
        library(glmnet)
      }
      la <- strsplit(model, "_")[[1]]
      alpha <- as.numeric(la[2])
      feature_G_train <- as.matrix(feature_G_train)
      feature_G_test <- as.matrix(feature_G_test)
      cv_fit_G <- cv.glmnet(feature_G_train, response_train, alpha = alpha, family = "gaussian")
      lasso_model_G <- glmnet(x = as.matrix(feature_G_train), y = response_train, family = "gaussian", alpha = 1, lambda = cv_fit_G$lambda.min)
      features_train_G <- predict(lasso_model_G, newx = as.matrix(feature_G_train), type = "response")
      features_test_G <- predict(lasso_model_G, newx = as.matrix(feature_G_test), type = "response")
      feature_P_train <- as.matrix(feature_P_train)
      feature_P_test <- as.matrix(feature_P_test)
      cv_fit_P <- cv.glmnet(feature_P_train, response_train, alpha = alpha, family = "gaussian")
      lasso_model_P <- glmnet(x = as.matrix(feature_P_train), y = response_train, family = "gaussian", alpha = 1, lambda = cv_fit_P$lambda.min)
      features_train_P <- predict(lasso_model_P, newx = as.matrix(feature_P_train), type = "response")
      features_test_P <- predict(lasso_model_P, newx = as.matrix(feature_P_test), type = "response")
      train_features <- cbind(features_train_G, features_train_P)
      test_features <- cbind(features_test_G, features_test_P)
      cv_lasso_combined <- cv.glmnet(train_features, response_train, alpha = alpha, family = "gaussian")
      lasso_combined <- glmnet(train_features, response_train, alpha = alpha, family = "gaussian", lambda = cv_lasso_combined$lambda.min)
      final_pred <- predict(lasso_combined, test_features, s = lasso_combined$lambda.min)
    }else if(grepl("LightGBM", model)){
      if(!require(lightgbm)){
        install.packages("lightgbm")
        library(lightgbm)
      }
      li <- strsplit(model, "_")[[1]]
      nrounds <- as.numeric(li[2])
      colnames(feature_G_train) <- make.names(colnames(feature_G_train))
      colnames(feature_G_test) <- make.names(colnames(feature_G_test))
      colnames(feature_P_train) <- make.names(colnames(feature_P_train))
      colnames(feature_P_test) <- make.names(colnames(feature_P_test))
      train_data_G <- lgb.Dataset(data = as.matrix(feature_G_train), label = response_train)
      test_data_G <- lgb.Dataset(data = as.matrix(feature_G_test), label = response_test)
      params <- list(
        objective = "regression",  # 回归任务
        metric = "rmse",           # 评估指标为均方根误差
        learning_rate = 0.1,
        num_leaves = 31,
        min_data_in_leaf = 20
      )
      G_Lightgbm_model <- lgb.train(params = params, data = train_data_G, nrounds = nrounds)
      pred_G_train <- predict(G_Lightgbm_model, as.matrix(feature_G_train), type = 'leaf')
      pred_G_test <- predict(G_Lightgbm_model, as.matrix(feature_G_test), type = 'leaf')
      train_data_P <- lgb.Dataset(data = as.matrix(feature_P_train), label = response_train)
      test_data_P <- lgb.Dataset(data = as.matrix(feature_P_test), label = response_test)
      P_Lightgbm_model <- lgb.train(params = params, data = train_data_P, nrounds = nrounds)
      pred_P_train <- predict(P_Lightgbm_model, as.matrix(feature_P_train), type = 'leaf')
      pred_P_test <- predict(P_Lightgbm_model, as.matrix(feature_P_test), type = 'leaf')
      combined_features_train <- cbind(pred_G_train, pred_P_train)
      combined_features_test <- cbind(pred_G_test, pred_P_test)
      train_combined <- lgb.Dataset(combined_features_train, label = response_train)
      lgb_combined <- lgb.train(params, train_combined, 100)
      final_pred <- predict(lgb_combined, combined_features_test)
    }else if(grepl("SVM", model)){
      if(!require(e1071)){
        install.packages("e1071")
        library(e1071)
      }
      G_SVM_model <- svm(feature_G_train, response_train, kernel = "linear", cost = 10, scale = TRUE, type = "eps-regression")
      features_G_train <- predict(G_SVM_model, feature_G_train, decision.values = TRUE)
      decisions_G_train <- attr(features_G_train, "decision.values")
      features_G_test <- predict(G_SVM_model, feature_G_test, decision.values = TRUE)
      decisions_G_test <- attr(features_G_test, "decision.values")
      P_SVM_model <- svm(feature_P_train, response_train, kernel = "linear", cost = 10, scale = TRUE, type = "eps-regression")
      features_P_train <- predict(P_SVM_model, feature_P_train, decision.values = TRUE)
      decisions_P_train <- attr(features_P_train, "decision.values")
      features_P_test <- predict(P_SVM_model, feature_P_test, decision.values = TRUE)
      decisions_P_test <- attr(features_P_test, "decision.values")
      combined_features_train <- cbind(decisions_G_train, decisions_P_train)
      combined_features_test <- cbind(decisions_G_test, decisions_P_test)
      final_model <- svm(combined_features_train, response_train, kernel = "linear", cost = 10, scale = TRUE, type = "eps-regression")
      final_pred <- predict(final_model,combined_features_test)
    }else if(grepl("XGBoost", model)){
      if(!require(xgboost)){
        install.packages("xgboost")
        library(xgboost)
      }
      xg <- strsplit(model, "_")[[1]]
      nrounds <- as.numeric(xg[2])
      params <- list(
        objective = "reg:squarederror",  # 回归任务的目标函数
        eval_metric = "rmse"             # 评估指标为均方根误差
      )
      G_XGBoost_model <- xgboost(data = as.matrix(feature_G_train), label = response_train, nrounds = nrounds, params = params, verbose = 0)
      features_G_train <- predict(G_XGBoost_model, as.matrix(feature_G_train), predleaf = TRUE)
      features_G_test <- predict(G_XGBoost_model, as.matrix(feature_G_test), predleaf = TRUE)
      P_XGBoost_model <- xgboost(data = as.matrix(feature_P_train), label = response_train, nrounds = nrounds, params = params, verbose = 0)
      features_P_train <- predict(P_XGBoost_model, as.matrix(feature_P_train), predleaf = TRUE)
      features_P_test <- predict(P_XGBoost_model, as.matrix(feature_P_test), predleaf = TRUE)
      combined_features_train <- cbind(features_G_train, features_P_train)
      combined_features_test <- cbind(features_G_test, features_P_test)
      final_model <- xgboost(data = as.matrix(combined_features_train), label = response_train, nrounds = nrounds, params = params, verbose = 0)
      final_pred <- predict(final_model, as.matrix(combined_features_test))
    }else{
      message("The input model is incorrect.")
    }
    final_pred <- as.numeric(final_pred)
    all_val_preds <- c(all_val_preds, final_pred)
    all_actuals <- c(all_actuals, response_test)
  }
  out <- data.frame(all_actuals, all_val_preds)
  return(out)
}
